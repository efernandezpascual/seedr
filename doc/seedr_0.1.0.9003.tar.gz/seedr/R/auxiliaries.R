# Format input data.frame =========================================

#' @import data.table
#' @export

physiotable <- function(d, t, g, pg, x, reps = NULL, groups = NULL)
{
  i <- sapply(d, is.factor)
  d[i] <- lapply(d[i], as.character)
  d <- data.table(d, stringsAsFactors = FALSE)
  d <- d[, .(germinated = sum(get(g)), germinable = sum(get(pg))),
         by = c(x, t, groups, reps)]
  d[, germinable := max(germinable), by = c(x, reps, groups)]
  setorderv(d, c(groups, reps, x, t))
  d[, cumulative := cumsum(germinated), by = c(x, reps, groups)]
  d[, germination := cumulative / germinable]
}

# Calculate germination proportions with CI ==========================

#' @export

proportions <- function(d, x, reps = NULL)
{
  d1 <- d[, .(germinated = max(cumulative), germinable = max(germinable)), by = c(x, reps)]
  d1 <- d1[, .(germinated = sum(germinated), germinable = sum(germinable)), by = x]
  d1[, proportion := germinated / germinable, by = x]
  d1[, lower := binom.lower(germinated, germinable), by = x] # FASTER DATA.TABLE WAY?
  d1[, upper := binom.upper(germinated, germinable), by = x] # FASTER DATA.TABLE WAY?
}

#' @export

binom.lower <- function(x, n) # FASTER DATA.TABLE WAY?
{
  ci <- binom.test(x, n)
  ci$conf.int[1]
}

#' @export

binom.upper <- function(x, n) # FASTER DATA.TABLE WAY?
{
  ci <- binom.test(x, n)
  ci$conf.int[2]
}
