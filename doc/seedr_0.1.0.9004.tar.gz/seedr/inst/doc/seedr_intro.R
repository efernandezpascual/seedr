## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(seedr)

## -----------------------------------------------------------------------------
cent <- physiodata(centaury, x = "temperature") # the x argument denotes the experimental treatment, usually water potential or temperature

## -----------------------------------------------------------------------------
summary(cent)

## ----fig.width = 7, fig.height = 5--------------------------------------------
plot(cent)

## ----fig.width = 7, fig.height = 5--------------------------------------------
barplot(cent)

## ----fig.width = 7, fig.height = 5--------------------------------------------
grass <- physiodata(grasses, x = "psi", groups = "species") # the x argument denotes the experimental treatment, usually water potential or temperature
plot(grass)

## -----------------------------------------------------------------------------
anisantha <- physiodata(subset(grasses, species == "Anisantha rubens"), x = "psi") # select only one species
b <- bradford(anisantha$proportions) # bradford() uses the $proportions element within the physiodata object
b

## ----fig.width = 7, fig.height = 5--------------------------------------------
plot(b)

## -----------------------------------------------------------------------------
malva <- physiodata(subset(centaury, population == "La Malva"), x = "temperature") # select only one population
h <- huidobro(malva$proportions) # huidobro() uses the $proportions element within the physiodata object
h

## ----fig.width = 7, fig.height = 5--------------------------------------------
plot(h)

## -----------------------------------------------------------------------------
m <- physiotime(centaury, x = "temperature", method = "huidobro", groups = c("species", "population"))
m

## -----------------------------------------------------------------------------
summary(m)

## ----fig.width = 7, fig.height = 5--------------------------------------------
plot(m)

